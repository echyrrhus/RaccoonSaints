import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import AdBanner from "@/components/ad-banner";

export default function WebcomicApp() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Please log in",
        description: "You need to log in to access the webcomic platform.",
        variant: "default",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: webcomicsData, isLoading: webcomicsLoading } = useQuery({
    queryKey: ["/api/webcomics"],
    enabled: isAuthenticated,
  });

  const webcomics = webcomicsData?.webcomics || [];

  if (isLoading || webcomicsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/app" className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-brand-emerald rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">R</span>
                </div>
                <span className="font-semibold text-slate-800">RaccoonSaints</span>
              </Link>
            </div>
            
            <nav className="flex items-center space-x-6">
              <Link href="/app" className="text-slate-600 hover:text-brand-emerald transition-colors">
                Browse Comics
              </Link>
              <Link href="/creator" className="text-slate-600 hover:text-brand-emerald transition-colors">
                Creator Portal
              </Link>
              <a 
                href="https://docs.google.com/forms/d/e/1FAIpQLScufDB-Uw0HBMdNsYZUDk5hxMtoU7si95SfQKzJ-qAI2vmiyA/viewform?usp=dialog"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-600 hover:text-brand-emerald transition-colors"
              >
                Contributor Link
              </a>
              <Button 
                onClick={() => window.location.href = "/api/logout"}
                variant="outline"
                size="sm"
              >
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-12 gap-6">
          {/* Left sidebar - Ads */}
          <div className="col-span-2">
            <AdBanner position="left" />
          </div>

          {/* Main content */}
          <div className="col-span-8">
            <div className="mb-8">
              <h1 className="text-3xl font-bold text-slate-800 mb-2">
                Welcome to RaccoonSaints
              </h1>
              <p className="text-lg text-slate-600">
                Discover amazing webcomics that support meaningful causes
              </p>
            </div>

            {/* Top ad banner */}
            <div className="mb-6">
              <AdBanner position="top" />
            </div>

            {/* Webcomics grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {webcomics.length === 0 ? (
                <div className="col-span-full text-center py-12">
                  <p className="text-slate-500 text-lg">No webcomics available yet.</p>
                  <p className="text-slate-400 mt-2">Check back soon for new content!</p>
                </div>
              ) : (
                webcomics.map((webcomic: any) => (
                  <Card key={webcomic.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{webcomic.title}</CardTitle>
                        <Badge variant="secondary">Published</Badge>
                      </div>
                      <CardDescription>
                        By {webcomic.creator.username}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-600 mb-4 line-clamp-3">
                        {webcomic.description || "A compelling webcomic story awaits..."}
                      </p>
                      <Link href={`/comics/${webcomic.id}`}>
                        <Button className="w-full bg-brand-emerald hover:bg-emerald-600">
                          Read Comic
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>

            {/* Bottom ad banner */}
            <div className="mt-8">
              <AdBanner position="bottom" />
            </div>
          </div>

          {/* Right sidebar - Ads */}
          <div className="col-span-2">
            <AdBanner position="right" />
          </div>
        </div>
      </div>
    </div>
  );
}