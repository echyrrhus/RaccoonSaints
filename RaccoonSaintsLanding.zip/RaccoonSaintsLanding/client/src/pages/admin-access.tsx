import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AdminAccess() {
  const [showAdmin, setShowAdmin] = useState(false);

  const { data: adminUser, isLoading } = useQuery({
    queryKey: ["/api/admin-bypass"],
    enabled: showAdmin,
  });

  useEffect(() => {
    // Auto-enable admin mode
    setShowAdmin(true);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Admin Access</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600 mb-4">Loading admin access...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!adminUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Admin Access Failed</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-slate-600 mb-4">Could not load admin user.</p>
            <Button onClick={() => window.location.reload()}>Try Again</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
      <Card className="max-w-md w-full">
        <CardHeader>
          <CardTitle>Welcome, Admin!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-slate-600">
            You now have full admin access to the RaccoonSaints platform.
          </p>
          
          <div className="space-y-2">
            <Link href="/app">
              <Button className="w-full bg-brand-emerald hover:bg-emerald-600">
                Enter Main App
              </Button>
            </Link>
            
            <Link href="/admin">
              <Button variant="outline" className="w-full">
                Go to Admin Dashboard
              </Button>
            </Link>
            
            <Link href="/creator">
              <Button variant="outline" className="w-full">
                Creator Dashboard
              </Button>
            </Link>
          </div>
          
          <div className="text-xs text-slate-500 pt-4">
            <p>Admin User: {(adminUser as any)?.username || 'N/A'}</p>
            <p>Role: {(adminUser as any)?.role || 'N/A'}</p>
            <details className="mt-2">
              <summary>Debug Info</summary>
              <pre className="text-xs bg-slate-100 p-2 rounded mt-1">
                {JSON.stringify(adminUser, null, 2)}
              </pre>
            </details>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}