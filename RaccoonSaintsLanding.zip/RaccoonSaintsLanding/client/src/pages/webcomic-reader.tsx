import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronLeft, ChevronRight, ArrowLeft } from "lucide-react";
import AdBanner from "@/components/ad-banner";

export default function WebcomicReader() {
  const [, params] = useRoute("/comics/:id");
  const webcomicId = params?.id;
  const [currentPage, setCurrentPage] = useState(0);

  const { data: webcomicData, isLoading: webcomicLoading } = useQuery({
    queryKey: ["/api/webcomics", webcomicId],
  });

  const { data: pagesData, isLoading: pagesLoading } = useQuery({
    queryKey: ["/api/webcomics", webcomicId, "pages"],
    enabled: !!webcomicId,
  });

  const webcomic = webcomicData?.webcomic;
  const pages = pagesData?.pages || [];

  if (webcomicLoading || pagesLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-lg">Loading comic...</div>
      </div>
    );
  }

  if (!webcomic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Comic not found</h1>
          <Link href="/app">
            <Button>Back to Comics</Button>
          </Link>
        </div>
      </div>
    );
  }

  const currentPageData = pages[currentPage];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/app" className="flex items-center space-x-2 text-slate-600 hover:text-brand-emerald">
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Comics</span>
              </Link>
            </div>
            
            <div className="text-center">
              <h1 className="text-xl font-bold text-slate-800">{webcomic.title}</h1>
              <p className="text-sm text-slate-600">by {webcomic.creator.username}</p>
            </div>
            
            <div className="text-sm text-slate-500">
              Page {currentPage + 1} of {pages.length}
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-12 gap-6">
          {/* Left sidebar - Ads */}
          <div className="col-span-2">
            <AdBanner position="left" />
          </div>

          {/* Main comic reader */}
          <div className="col-span-8">
            {pages.length === 0 ? (
              <Card className="p-8 text-center">
                <h2 className="text-xl font-semibold mb-2">No pages available</h2>
                <p className="text-slate-600">This comic doesn't have any published pages yet.</p>
              </Card>
            ) : (
              <div className="space-y-6">
                {/* Comic page */}
                <Card className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative bg-white">
                      <img
                        src={currentPageData?.imageUrl || "/placeholder-comic.png"}
                        alt={currentPageData?.altText || `Page ${currentPage + 1}`}
                        className="w-full h-auto max-h-[80vh] object-contain mx-auto"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAwIiBoZWlnaHQ9IjYwMCIgdmlld0JveD0iMCAwIDgwMCA2MDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI4MDAiIGhlaWdodD0iNjAwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik00MDAgMjUwQzQyMi4wOTEgMjUwIDQ0MCAyNjcuOTA5IDQ0MCAyOTBDNDQwIDMxMi4wOTEgNDIyLjA5MSAzMzAgNDAwIDMzMEM0MzcuOTA5IDMzMCAzNjAgMzEyLjA5MSAzNjAgMjkwQzM2MCAyNjcuOTA5IDM3Ny45MDkgMjUwIDQwMCAyNTBaIiBmaWxsPSIjOTcxMTM5Ii8+CjxwYXRoIGQ9Ik0zNjUgMjYwSDQzNVYzMDBIMzY1VjI2MFoiIGZpbGw9IiM5NzExMzkiLz4KPHRLEHA+Q29taWMgUGFnZSBOb3QgRm91bmQ8L3A+PC90ZXh0Pgo8L3N2Zz4K";
                        }}
                      />
                    </div>
                  </CardContent>
                </Card>

                {/* Navigation */}
                <div className="flex justify-between items-center">
                  <Button
                    onClick={() => setCurrentPage(Math.max(0, currentPage - 1))}
                    disabled={currentPage === 0}
                    variant="outline"
                    className="flex items-center space-x-2"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>Previous</span>
                  </Button>

                  <div className="flex items-center space-x-2">
                    {pages.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentPage(index)}
                        className={`w-3 h-3 rounded-full transition-colors ${
                          index === currentPage 
                            ? 'bg-brand-emerald' 
                            : 'bg-slate-300 hover:bg-slate-400'
                        }`}
                      />
                    ))}
                  </div>

                  <Button
                    onClick={() => setCurrentPage(Math.min(pages.length - 1, currentPage + 1))}
                    disabled={currentPage === pages.length - 1}
                    variant="outline"
                    className="flex items-center space-x-2"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>

                {/* Page info */}
                {currentPageData?.title && (
                  <Card className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{currentPageData.title}</h3>
                    {currentPageData.altText && (
                      <p className="text-slate-600">{currentPageData.altText}</p>
                    )}
                  </Card>
                )}
              </div>
            )}
          </div>

          {/* Right sidebar - Ads */}
          <div className="col-span-2">
            <AdBanner position="right" />
          </div>
        </div>
      </div>
    </div>
  );
}