import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Eye, ArrowLeft } from "lucide-react";

export default function CreatorDashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect if not authenticated or not a creator/admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || (user && !['creator', 'admin'].includes(user.role)))) {
      toast({
        title: "Access Denied",
        description: "You need creator permissions to access this page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/app";
      }, 1500);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: webcomicsData, isLoading: webcomicsLoading } = useQuery({
    queryKey: ["/api/creator/webcomics"],
    enabled: isAuthenticated && user?.role && ['creator', 'admin'].includes(user.role),
  });

  const webcomics = webcomicsData?.webcomics || [];

  if (isLoading || webcomicsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated || !user || !['creator', 'admin'].includes(user.role)) {
    return null; // Will redirect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/app" className="flex items-center space-x-2 text-slate-600 hover:text-brand-emerald">
                <ArrowLeft className="w-4 h-4" />
                <span>Back to App</span>
              </Link>
            </div>
            
            <div className="text-center">
              <h1 className="text-xl font-bold text-slate-800">Creator Dashboard</h1>
              <p className="text-sm text-slate-600">Manage your webcomics</p>
            </div>
            
            <nav className="flex items-center space-x-4">
              {user.role === 'admin' && (
                <Link href="/admin">
                  <Button variant="outline" size="sm">
                    Admin Panel
                  </Button>
                </Link>
              )}
              <Button 
                onClick={() => window.location.href = "/api/logout"}
                variant="outline"
                size="sm"
              >
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">Your Webcomics</h2>
            <p className="text-slate-600 mt-1">Create and manage your comic series</p>
          </div>
          
          <Button className="bg-brand-emerald hover:bg-emerald-600 flex items-center space-x-2">
            <Plus className="w-4 h-4" />
            <span>New Comic</span>
          </Button>
        </div>

        {webcomics.length === 0 ? (
          <Card className="p-12 text-center">
            <div className="max-w-md mx-auto">
              <h3 className="text-xl font-semibold mb-4">No webcomics yet</h3>
              <p className="text-slate-600 mb-6">
                Start creating your first webcomic series and share your story with the world.
              </p>
              <Button className="bg-brand-emerald hover:bg-emerald-600 flex items-center space-x-2 mx-auto">
                <Plus className="w-4 h-4" />
                <span>Create Your First Comic</span>
              </Button>
            </div>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {webcomics.map((webcomic: any) => (
              <Card key={webcomic.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-lg">{webcomic.title}</CardTitle>
                    <Badge variant={webcomic.isPublished ? "default" : "secondary"}>
                      {webcomic.isPublished ? "Published" : "Draft"}
                    </Badge>
                  </div>
                  <CardDescription>
                    Created {new Date(webcomic.createdAt).toLocaleDateString()}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600 mb-4 line-clamp-3">
                    {webcomic.description || "No description provided."}
                  </p>
                  
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    
                    {webcomic.isPublished && (
                      <Link href={`/comics/${webcomic.id}`}>
                        <Button variant="outline" size="sm" className="flex-1">
                          <Eye className="w-3 h-3 mr-1" />
                          View
                        </Button>
                      </Link>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Quick stats */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Total Comics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-brand-emerald">{webcomics.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Published</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {webcomics.filter((w: any) => w.isPublished).length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Drafts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">
                {webcomics.filter((w: any) => !w.isPublished).length}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}