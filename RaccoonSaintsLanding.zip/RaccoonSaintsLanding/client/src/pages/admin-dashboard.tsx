import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Edit, Trash2, ArrowLeft, Users, Mail, Image } from "lucide-react";

export default function AdminDashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || (user && user.role !== 'admin'))) {
      toast({
        title: "Access Denied",
        description: "You need admin permissions to access this page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/app";
      }, 1500);
      return;
    }
  }, [isAuthenticated, isLoading, user, toast]);

  const { data: adsData, isLoading: adsLoading } = useQuery({
    queryKey: ["/api/admin/advertisements"],
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const { data: subscriptionsData, isLoading: subscriptionsLoading } = useQuery({
    queryKey: ["/api/subscriptions"],
    enabled: isAuthenticated && user?.role === 'admin',
  });

  const advertisements = adsData?.advertisements || [];
  const subscriptions = subscriptionsData?.subscriptions || [];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!isAuthenticated || !user || user.role !== 'admin') {
    return null; // Will redirect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Link href="/app" className="flex items-center space-x-2 text-slate-600 hover:text-brand-emerald">
                <ArrowLeft className="w-4 h-4" />
                <span>Back to App</span>
              </Link>
            </div>
            
            <div className="text-center">
              <h1 className="text-xl font-bold text-slate-800">Admin Dashboard</h1>
              <p className="text-sm text-slate-600">Manage platform settings</p>
            </div>
            
            <nav className="flex items-center space-x-4">
              <Link href="/creator">
                <Button variant="outline" size="sm">
                  Creator Portal
                </Button>
              </Link>
              <Button 
                onClick={() => window.location.href = "/api/logout"}
                variant="outline"
                size="sm"
              >
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Quick stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-lg">Email Subscribers</CardTitle>
              <Mail className="h-5 w-5 text-brand-emerald" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-brand-emerald">{subscriptions.length}</div>
              <p className="text-sm text-slate-600 mt-1">Newsletter signups</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-lg">Active Ads</CardTitle>
              <Image className="h-5 w-5 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {advertisements.filter((ad: any) => ad.isActive).length}
              </div>
              <p className="text-sm text-slate-600 mt-1">Currently displaying</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-lg">Total Ads</CardTitle>
              <Image className="h-5 w-5 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-600">{advertisements.length}</div>
              <p className="text-sm text-slate-600 mt-1">All advertisements</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="advertisements" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="advertisements">Advertisements</TabsTrigger>
            <TabsTrigger value="subscribers">Email Subscribers</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
          </TabsList>

          <TabsContent value="advertisements" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-semibold">Advertisement Management</h3>
                <p className="text-slate-600">Manage clickable ads displayed around the webcomic reader</p>
              </div>
              <Button className="bg-brand-emerald hover:bg-emerald-600 flex items-center space-x-2">
                <Plus className="w-4 h-4" />
                <span>Add Advertisement</span>
              </Button>
            </div>

            {adsLoading ? (
              <div className="text-center py-8">Loading advertisements...</div>
            ) : advertisements.length === 0 ? (
              <Card className="p-12 text-center">
                <h4 className="text-lg font-semibold mb-2">No advertisements yet</h4>
                <p className="text-slate-600 mb-4">Create your first advertisement to display around comics</p>
                <Button className="bg-brand-emerald hover:bg-emerald-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Ad
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {advertisements.map((ad: any) => (
                  <Card key={ad.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{ad.title}</CardTitle>
                        <Badge variant={ad.isActive ? "default" : "secondary"}>
                          {ad.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                      <CardDescription>Position: {ad.position}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="aspect-video bg-slate-100 rounded-md overflow-hidden">
                          <img
                            src={ad.imageUrl}
                            alt={ad.altText || ad.title}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              (e.target as HTMLImageElement).style.display = 'none';
                            }}
                          />
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Edit className="w-3 h-3 mr-1" />
                            Edit
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1 text-red-600 hover:text-red-700">
                            <Trash2 className="w-3 h-3 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="subscribers" className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold">Email Subscribers</h3>
              <p className="text-slate-600">People who signed up for launch notifications</p>
            </div>

            {subscriptionsLoading ? (
              <div className="text-center py-8">Loading subscribers...</div>
            ) : subscriptions.length === 0 ? (
              <Card className="p-12 text-center">
                <h4 className="text-lg font-semibold mb-2">No subscribers yet</h4>
                <p className="text-slate-600">Email subscribers will appear here when people sign up</p>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Subscriber List ({subscriptions.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {subscriptions.map((subscription: any) => (
                      <div key={subscription.id} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
                        <div>
                          <p className="font-medium">{subscription.email}</p>
                          <p className="text-sm text-slate-600">
                            Subscribed {new Date(subscription.subscribedAt).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge variant={subscription.acceptsUpdates ? "default" : "secondary"}>
                          {subscription.acceptsUpdates ? "Accepts Updates" : "Launch Only"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-xl font-semibold">User Management</h3>
                <p className="text-slate-600">Create and manage creator accounts</p>
              </div>
              <Button className="bg-brand-emerald hover:bg-emerald-600 flex items-center space-x-2">
                <Plus className="w-4 h-4" />
                <span>Create Creator Account</span>
              </Button>
            </div>

            <Card className="p-12 text-center">
              <Users className="w-16 h-16 text-slate-400 mx-auto mb-4" />
              <h4 className="text-lg font-semibold mb-2">User Management</h4>
              <p className="text-slate-600 mb-4">
                Create login credentials for creators who can publish webcomics to the platform
              </p>
              <Button className="bg-brand-emerald hover:bg-emerald-600">
                <Plus className="w-4 h-4 mr-2" />
                Create First Creator Account
              </Button>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}