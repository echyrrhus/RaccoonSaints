export default function Footer() {
  return (
    <footer className="py-8 px-4 border-t border-slate-200">
      <div className="max-w-6xl mx-auto text-center">
        <p className="text-slate-500 text-sm">
          © 2024 RaccoonSaints. Building a better world, one comic at a time.
        </p>
        <div className="mt-4 flex justify-center space-x-6">
          <a 
            href="#" 
            className="text-slate-400 hover:text-brand-emerald transition-colors duration-200"
          >
            Privacy
          </a>
          <a 
            href="#" 
            className="text-slate-400 hover:text-brand-emerald transition-colors duration-200"
          >
            Terms
          </a>
          <a 
            href="#" 
            className="text-slate-400 hover:text-brand-emerald transition-colors duration-200"
          >
            Contact
          </a>
        </div>
      </div>
    </footer>
  );
}
