import { User, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const { user, isAuthenticated, isLoading } = useAuth();

  return (
    <header className="w-full py-6 px-4">
      <nav className="max-w-6xl mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-brand-emerald rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-sm">R</span>
          </div>
          <span className="font-semibold text-slate-800">RaccoonSaints</span>
        </div>
        <div className="hidden md:flex space-x-6 items-center">
          <a 
            href="/" 
            className="text-slate-600 hover:text-brand-emerald transition-colors duration-200"
          >
            About
          </a>
          <a 
            href="https://docs.google.com/forms/d/e/1FAIpQLScufDB-Uw0HBMdNsYZUDk5hxMtoU7si95SfQKzJ-qAI2vmiyA/viewform?usp=dialog"
            target="_blank"
            rel="noopener noreferrer"
            className="text-slate-600 hover:text-brand-emerald transition-colors duration-200"
          >
            Contributor Link
          </a>
          
          {!isLoading && (
            <>
              {isAuthenticated && user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <User className="h-4 w-4" />
                      {(user as any)?.username || 'User'}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <a href="/app" className="w-full">
                        Main App
                      </a>
                    </DropdownMenuItem>
                    {(user as any)?.role === 'creator' || (user as any)?.role === 'admin' ? (
                      <DropdownMenuItem asChild>
                        <a href="/creator" className="w-full">
                          Creator Dashboard
                        </a>
                      </DropdownMenuItem>
                    ) : null}
                    {(user as any)?.role === 'admin' ? (
                      <DropdownMenuItem asChild>
                        <a href="/admin" className="w-full">
                          Admin Dashboard
                        </a>
                      </DropdownMenuItem>
                    ) : null}
                    <DropdownMenuItem asChild>
                      <a href="/api/logout" className="w-full flex items-center gap-2">
                        <LogOut className="h-4 w-4" />
                        Logout
                      </a>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <a 
                  href="/auth"
                  className="bg-brand-emerald hover:bg-emerald-600 text-white px-4 py-2 rounded-lg transition-colors duration-200"
                >
                  Enter App
                </a>
              )}
            </>
          )}
        </div>
      </nav>
    </header>
  );
}
