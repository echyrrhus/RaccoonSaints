export default function FeaturePreview() {
  return (
    <section className="px-4 pb-16">
      <div className="max-w-3xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="text-center p-6 bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="w-12 h-12 bg-brand-orange rounded-lg mx-auto mb-4 flex items-center justify-center">
            <span className="text-white font-bold text-xl">📚</span>
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Original Comics</h3>
          <p className="text-slate-600 text-sm">Discover unique stories from talented creators</p>
        </div>
        
        <div className="text-center p-6 bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="w-12 h-12 bg-brand-emerald rounded-lg mx-auto mb-4 flex items-center justify-center">
            <span className="text-white font-bold text-xl">❤️</span>
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Charity Focus</h3>
          <p className="text-slate-600 text-sm">Every story supports a meaningful cause</p>
        </div>
        
        <div className="text-center p-6 bg-white rounded-xl shadow-sm border border-slate-200">
          <div className="w-12 h-12 bg-slate-600 rounded-lg mx-auto mb-4 flex items-center justify-center">
            <span className="text-white font-bold text-xl">🌟</span>
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Community</h3>
          <p className="text-slate-600 text-sm">Join a community of compassionate creators</p>
        </div>
      </div>
    </section>
  );
}
