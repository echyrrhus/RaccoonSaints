import { useState } from "react";
import { Button } from "@/components/ui/button";
import SignupModal from "./signup-modal";

export default function HeroSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <section className="flex items-center justify-center px-4 py-12 md:py-24">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-12">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-slate-800 mb-6 leading-tight">
              <span className="bg-gradient-to-r from-brand-emerald to-emerald-600 bg-clip-text text-transparent">
                RaccoonSaints
              </span>
            </h1>
            
            <p className="text-lg md:text-xl lg:text-2xl text-slate-600 mb-8 max-w-2xl mx-auto leading-relaxed">
              Charity-focused webcomic platform — launching soon!
            </p>
            
            <p className="text-base md:text-lg text-slate-500 mb-12 max-w-xl mx-auto">
              Where storytelling meets social impact. Join us in creating comics that inspire change and support meaningful causes.
            </p>
          </div>

          <div className="space-y-4">
            <Button 
              onClick={() => setIsModalOpen(true)}
              className="bg-brand-emerald hover:bg-emerald-600 text-white font-semibold px-8 py-4 rounded-lg text-lg transition-all duration-200 transform hover:scale-105 hover:shadow-lg focus:outline-none focus:ring-4 focus:ring-emerald-200 active:scale-95"
            >
              Notify Me
            </Button>
            <p className="text-sm text-slate-500">
              Be the first to know when we launch
            </p>
          </div>
        </div>
      </section>

      <SignupModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
}
