import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

interface AdBannerProps {
  position: "left" | "right" | "top" | "bottom";
}

export default function AdBanner({ position }: AdBannerProps) {
  const { data: adsData } = useQuery({
    queryKey: ["/api/advertisements"],
  });

  const advertisements = adsData?.advertisements || [];
  const positionAds = advertisements.filter((ad: any) => ad.position === position);

  if (positionAds.length === 0) {
    return (
      <div className={`${
        position === "top" || position === "bottom" 
          ? "h-24" 
          : "h-64"
      } mb-4`}>
        <Card className="h-full">
          <CardContent className="h-full flex items-center justify-center p-4">
            <div className="text-center text-slate-400">
              <p className="text-sm">Advertisement Space</p>
              <p className="text-xs">Contact admin to place ads</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {positionAds.map((ad: any) => (
        <Card key={ad.id} className="overflow-hidden hover:shadow-lg transition-shadow">
          <CardContent className="p-0">
            <a
              href={ad.linkUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="block"
            >
              <img
                src={ad.imageUrl}
                alt={ad.altText || ad.title}
                className={`w-full object-cover ${
                  position === "top" || position === "bottom"
                    ? "h-24"
                    : "h-64"
                }`}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const parent = target.parentElement;
                  if (parent) {
                    parent.innerHTML = `
                      <div class="h-full flex items-center justify-center bg-slate-100 text-slate-500 text-sm">
                        <div class="text-center">
                          <p>${ad.title}</p>
                          <p class="text-xs">Click to visit</p>
                        </div>
                      </div>
                    `;
                  }
                }}
              />
            </a>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}