import { pgTable, text, serial, integer, boolean, timestamp, varchar, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// User management with role-based access
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 50 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  role: varchar("role", { length: 20 }).notNull().default("standard"), // standard, creator, admin
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Email subscriptions for landing page
export const emailSubscriptions = pgTable("email_subscriptions", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  acceptsUpdates: boolean("accepts_updates").notNull().default(false),
  subscribedAt: timestamp("subscribed_at").notNull().defaultNow(),
});

// Sessions for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: text("sess").notNull(),
    expire: timestamp("expire").notNull(),
  }
);

// Webcomics
export const webcomics = pgTable("webcomics", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  creatorId: integer("creator_id").notNull().references(() => users.id),
  isPublished: boolean("is_published").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Webcomic pages/episodes
export const webcomicPages = pgTable("webcomic_pages", {
  id: serial("id").primaryKey(),
  webcomicId: integer("webcomic_id").notNull().references(() => webcomics.id),
  title: varchar("title", { length: 255 }),
  pageNumber: integer("page_number").notNull(),
  imageUrl: text("image_url").notNull(),
  altText: text("alt_text"),
  isPublished: boolean("is_published").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
}, (table) => [
  unique().on(table.webcomicId, table.pageNumber)
]);

// Advertisements
export const advertisements = pgTable("advertisements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  imageUrl: text("image_url").notNull(),
  linkUrl: text("link_url").notNull(),
  altText: text("alt_text"),
  position: varchar("position", { length: 20 }).notNull(), // left, right, top, bottom
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Webcomic subscriptions for users
export const webcomicSubscriptions = pgTable("webcomic_subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  webcomicId: integer("webcomic_id").notNull().references(() => webcomics.id, { onDelete: "cascade" }),
  subscribedAt: timestamp("subscribed_at").defaultNow(),
}, (table) => ({
  uniqueSubscription: unique().on(table.userId, table.webcomicId),
}));

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  webcomics: many(webcomics),
  subscriptions: many(webcomicSubscriptions),
}));

export const webcomicsRelations = relations(webcomics, ({ one, many }) => ({
  creator: one(users, {
    fields: [webcomics.creatorId],
    references: [users.id],
  }),
  pages: many(webcomicPages),
  subscriptions: many(webcomicSubscriptions),
}));

export const webcomicPagesRelations = relations(webcomicPages, ({ one }) => ({
  webcomic: one(webcomics, {
    fields: [webcomicPages.webcomicId],
    references: [webcomics.id],
  }),
}));

export const webcomicSubscriptionsRelations = relations(webcomicSubscriptions, ({ one }) => ({
  user: one(users, {
    fields: [webcomicSubscriptions.userId],
    references: [users.id],
  }),
  webcomic: one(webcomics, {
    fields: [webcomicSubscriptions.webcomicId],
    references: [webcomics.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  role: true,
});

export const insertWebcomicSchema = createInsertSchema(webcomics).pick({
  title: true,
  description: true,
  creatorId: true,
  isPublished: true,
});

export const insertWebcomicPageSchema = createInsertSchema(webcomicPages).pick({
  webcomicId: true,
  title: true,
  pageNumber: true,
  imageUrl: true,
  altText: true,
  isPublished: true,
});

export const insertAdvertisementSchema = createInsertSchema(advertisements).pick({
  title: true,
  imageUrl: true,
  linkUrl: true,
  altText: true,
  position: true,
  isActive: true,
});

export const insertEmailSubscriptionSchema = createInsertSchema(emailSubscriptions).pick({
  email: true,
  acceptsUpdates: true,
}).extend({
  email: z.string().email("Please enter a valid email address"),
});

export const insertWebcomicSubscriptionSchema = createInsertSchema(webcomicSubscriptions).pick({
  userId: true,
  webcomicId: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type UpsertUser = typeof users.$inferInsert;

export type Webcomic = typeof webcomics.$inferSelect;
export type InsertWebcomic = z.infer<typeof insertWebcomicSchema>;

export type WebcomicPage = typeof webcomicPages.$inferSelect;
export type InsertWebcomicPage = z.infer<typeof insertWebcomicPageSchema>;

export type Advertisement = typeof advertisements.$inferSelect;
export type InsertAdvertisement = z.infer<typeof insertAdvertisementSchema>;

export type EmailSubscription = typeof emailSubscriptions.$inferSelect;
export type InsertEmailSubscription = z.infer<typeof insertEmailSubscriptionSchema>;

export type WebcomicSubscription = typeof webcomicSubscriptions.$inferSelect;
export type InsertWebcomicSubscription = z.infer<typeof insertWebcomicSubscriptionSchema>;
