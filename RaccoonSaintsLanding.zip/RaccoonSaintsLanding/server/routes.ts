import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupCustomAuth, requireAuth, requireRole } from "./customAuth";
import { 
  insertEmailSubscriptionSchema,
  insertWebcomicSchema,
  insertWebcomicPageSchema,
  insertAdvertisementSchema 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  setupCustomAuth(app);

  // Temporary admin bypass route (remove in production)
  app.get('/api/admin-bypass', async (req, res) => {
    try {
      const adminUser = await storage.getUser('1'); // Get the admin user we created
      if (adminUser) {
        res.json(adminUser);
      } else {
        res.status(404).json({ message: "Admin user not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to get admin user" });
    }
  });

  // Note: Auth routes are now handled in customAuth.ts

  // Email subscription endpoint (public)
  app.post("/api/subscribe", async (req, res) => {
    try {
      const data = insertEmailSubscriptionSchema.parse(req.body);
      
      // Check if email already exists
      const existingSubscription = await storage.getEmailSubscriptionByEmail(data.email);
      if (existingSubscription) {
        return res.status(400).json({ 
          message: "This email is already subscribed" 
        });
      }

      const subscription = await storage.createEmailSubscription(data);
      res.status(201).json({ 
        message: "Successfully subscribed! We'll notify you when RaccoonSaints launches.",
        subscription: {
          id: subscription.id,
          email: subscription.email,
          subscribedAt: subscription.subscribedAt
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: error.errors[0]?.message || "Invalid input" 
        });
      } else {
        res.status(500).json({ 
          message: "An error occurred while subscribing" 
        });
      }
    }
  });

  // Get all subscriptions (admin only)
  app.get("/api/subscriptions", requireRole(['admin']), async (req, res) => {
    try {
      const subscriptions = await storage.getAllEmailSubscriptions();
      res.json({ subscriptions });
    } catch (error) {
      res.status(500).json({ 
        message: "An error occurred while fetching subscriptions" 
      });
    }
  });

  // Webcomic routes
  app.get("/api/webcomics", async (req, res) => {
    try {
      const webcomics = await storage.getWebcomics(true); // Only published
      res.json({ webcomics });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch webcomics" });
    }
  });

  app.get("/api/webcomics/:id", async (req, res) => {
    try {
      const webcomic = await storage.getWebcomic(parseInt(req.params.id));
      if (!webcomic || !webcomic.isPublished) {
        return res.status(404).json({ message: "Webcomic not found" });
      }
      res.json({ webcomic });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch webcomic" });
    }
  });

  app.get("/api/webcomics/:id/pages", async (req, res) => {
    try {
      const pages = await storage.getWebcomicPages(parseInt(req.params.id), true);
      res.json({ pages });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pages" });
    }
  });

  // Creator routes
  app.get("/api/creator/webcomics", requireRole(['creator', 'admin']), async (req: any, res) => {
    try {
      const userId = req.currentUser.id.toString();
      const webcomics = await storage.getWebcomicsByCreator(userId);
      res.json({ webcomics });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch webcomics" });
    }
  });

  app.post("/api/creator/webcomics", requireRole(['creator', 'admin']), async (req: any, res) => {
    try {
      const data = insertWebcomicSchema.parse({
        ...req.body,
        creatorId: req.currentUser.id
      });
      const webcomic = await storage.createWebcomic(data);
      res.status(201).json({ webcomic });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0]?.message || "Invalid input" });
      } else {
        res.status(500).json({ message: "Failed to create webcomic" });
      }
    }
  });

  app.put("/api/creator/webcomics/:id", requireRole(['creator', 'admin']), async (req: any, res) => {
    try {
      const webcomicId = parseInt(req.params.id);
      const existingWebcomic = await storage.getWebcomic(webcomicId);
      
      if (!existingWebcomic || (existingWebcomic.creatorId !== req.currentUser.id && req.currentUser.role !== 'admin')) {
        return res.status(404).json({ message: "Webcomic not found" });
      }

      const webcomic = await storage.updateWebcomic(webcomicId, req.body);
      res.json({ webcomic });
    } catch (error) {
      res.status(500).json({ message: "Failed to update webcomic" });
    }
  });

  app.post("/api/creator/webcomics/:id/pages", requireRole(['creator', 'admin']), async (req: any, res) => {
    try {
      const webcomicId = parseInt(req.params.id);
      const existingWebcomic = await storage.getWebcomic(webcomicId);
      
      if (!existingWebcomic || (existingWebcomic.creatorId !== req.currentUser.id && req.currentUser.role !== 'admin')) {
        return res.status(404).json({ message: "Webcomic not found" });
      }

      const data = insertWebcomicPageSchema.parse({
        ...req.body,
        webcomicId
      });
      const page = await storage.createWebcomicPage(data);
      res.status(201).json({ page });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0]?.message || "Invalid input" });
      } else {
        res.status(500).json({ message: "Failed to create page" });
      }
    }
  });

  // Admin routes
  app.get("/api/admin/users", requireRole(['admin']), async (req, res) => {
    try {
      // This would need a new storage method, for now return empty array
      res.json({ users: [] });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.post("/api/admin/users", requireRole(['admin']), async (req, res) => {
    try {
      const user = await storage.createUser(req.body);
      res.status(201).json({ user });
    } catch (error) {
      res.status(500).json({ message: "Failed to create user" });
    }
  });

  app.get("/api/admin/advertisements", requireRole(['admin']), async (req, res) => {
    try {
      const advertisements = await storage.getAdvertisements();
      res.json({ advertisements });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch advertisements" });
    }
  });

  app.post("/api/admin/advertisements", requireRole(['admin']), async (req, res) => {
    try {
      const data = insertAdvertisementSchema.parse(req.body);
      const advertisement = await storage.createAdvertisement(data);
      res.status(201).json({ advertisement });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0]?.message || "Invalid input" });
      } else {
        res.status(500).json({ message: "Failed to create advertisement" });
      }
    }
  });

  app.put("/api/admin/advertisements/:id", requireRole(['admin']), async (req, res) => {
    try {
      const advertisement = await storage.updateAdvertisement(parseInt(req.params.id), req.body);
      res.json({ advertisement });
    } catch (error) {
      res.status(500).json({ message: "Failed to update advertisement" });
    }
  });

  app.delete("/api/admin/advertisements/:id", requireRole(['admin']), async (req, res) => {
    try {
      await storage.deleteAdvertisement(parseInt(req.params.id));
      res.json({ message: "Advertisement deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete advertisement" });
    }
  });

  // Public advertisement endpoint
  app.get("/api/advertisements", async (req, res) => {
    try {
      const advertisements = await storage.getAdvertisements(true); // Only active ads
      res.json({ advertisements });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch advertisements" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
