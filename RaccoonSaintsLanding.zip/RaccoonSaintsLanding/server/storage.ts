import {
  users,
  emailSubscriptions,
  webcomics,
  webcomicPages,
  advertisements,
  webcomicSubscriptions,
  type User,
  type UpsertUser,
  type Webcomic,
  type InsertWebcomic,
  type WebcomicPage,
  type InsertWebcomicPage,
  type Advertisement,
  type InsertAdvertisement,
  type EmailSubscription,
  type InsertEmailSubscription,
  type WebcomicSubscription,
  type InsertWebcomicSubscription,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: any): Promise<User>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User>;
  
  // Webcomic operations
  getWebcomics(published?: boolean): Promise<(Webcomic & { creator: User })[]>;
  getWebcomic(id: number): Promise<(Webcomic & { creator: User }) | undefined>;
  getWebcomicsByCreator(creatorId: string): Promise<Webcomic[]>;
  createWebcomic(webcomic: InsertWebcomic): Promise<Webcomic>;
  updateWebcomic(id: number, updates: Partial<Webcomic>): Promise<Webcomic>;
  deleteWebcomic(id: number): Promise<void>;
  
  // Webcomic page operations
  getWebcomicPages(webcomicId: number, published?: boolean): Promise<WebcomicPage[]>;
  getWebcomicPage(id: number): Promise<WebcomicPage | undefined>;
  createWebcomicPage(page: InsertWebcomicPage): Promise<WebcomicPage>;
  updateWebcomicPage(id: number, updates: Partial<WebcomicPage>): Promise<WebcomicPage>;
  deleteWebcomicPage(id: number): Promise<void>;
  
  // Advertisement operations
  getAdvertisements(active?: boolean): Promise<Advertisement[]>;
  getAdvertisement(id: number): Promise<Advertisement | undefined>;
  createAdvertisement(ad: InsertAdvertisement): Promise<Advertisement>;
  updateAdvertisement(id: number, updates: Partial<Advertisement>): Promise<Advertisement>;
  deleteAdvertisement(id: number): Promise<void>;
  
  // Email subscription operations
  createEmailSubscription(subscription: InsertEmailSubscription): Promise<EmailSubscription>;
  getEmailSubscriptionByEmail(email: string): Promise<EmailSubscription | undefined>;
  getAllEmailSubscriptions(): Promise<EmailSubscription[]>;
  
  // Webcomic subscription operations
  createWebcomicSubscription(subscription: InsertWebcomicSubscription): Promise<WebcomicSubscription>;
  deleteWebcomicSubscription(userId: number, webcomicId: number): Promise<void>;
  getUserWebcomicSubscriptions(userId: number): Promise<WebcomicSubscription[]>;
  getWebcomicSubscribers(webcomicId: number): Promise<(WebcomicSubscription & { user: User })[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, parseInt(id)));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: any): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: userData.username,
        email: userData.email,
        password: userData.password,
        role: userData.role || "standard",
      })
      .returning();
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, parseInt(id)))
      .returning();
    return user;
  }

  // Webcomic operations
  async getWebcomics(published?: boolean): Promise<(Webcomic & { creator: User })[]> {
    const query = db
      .select({
        id: webcomics.id,
        title: webcomics.title,
        description: webcomics.description,
        creatorId: webcomics.creatorId,
        isPublished: webcomics.isPublished,
        createdAt: webcomics.createdAt,
        updatedAt: webcomics.updatedAt,
        creator: users,
      })
      .from(webcomics)
      .innerJoin(users, eq(webcomics.creatorId, users.id))
      .orderBy(desc(webcomics.createdAt));

    if (published !== undefined) {
      query.where(eq(webcomics.isPublished, published));
    }

    return await query;
  }

  async getWebcomic(id: number): Promise<(Webcomic & { creator: User }) | undefined> {
    const [result] = await db
      .select({
        id: webcomics.id,
        title: webcomics.title,
        description: webcomics.description,
        creatorId: webcomics.creatorId,
        isPublished: webcomics.isPublished,
        createdAt: webcomics.createdAt,
        updatedAt: webcomics.updatedAt,
        creator: users,
      })
      .from(webcomics)
      .innerJoin(users, eq(webcomics.creatorId, users.id))
      .where(eq(webcomics.id, id));

    return result;
  }

  async getWebcomicsByCreator(creatorId: string): Promise<Webcomic[]> {
    return await db
      .select()
      .from(webcomics)
      .where(eq(webcomics.creatorId, parseInt(creatorId)))
      .orderBy(desc(webcomics.createdAt));
  }

  async createWebcomic(webcomicData: InsertWebcomic): Promise<Webcomic> {
    const [webcomic] = await db.insert(webcomics).values(webcomicData).returning();
    return webcomic;
  }

  async updateWebcomic(id: number, updates: Partial<Webcomic>): Promise<Webcomic> {
    const [webcomic] = await db
      .update(webcomics)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(webcomics.id, id))
      .returning();
    return webcomic;
  }

  async deleteWebcomic(id: number): Promise<void> {
    await db.delete(webcomics).where(eq(webcomics.id, id));
  }

  // Webcomic page operations
  async getWebcomicPages(webcomicId: number, published?: boolean): Promise<WebcomicPage[]> {
    if (published !== undefined) {
      return await db
        .select()
        .from(webcomicPages)
        .where(and(
          eq(webcomicPages.webcomicId, webcomicId),
          eq(webcomicPages.isPublished, published)
        ))
        .orderBy(webcomicPages.pageNumber);
    }

    return await db
      .select()
      .from(webcomicPages)
      .where(eq(webcomicPages.webcomicId, webcomicId))
      .orderBy(webcomicPages.pageNumber);
  }

  async getWebcomicPage(id: number): Promise<WebcomicPage | undefined> {
    const [page] = await db.select().from(webcomicPages).where(eq(webcomicPages.id, id));
    return page;
  }

  async createWebcomicPage(pageData: InsertWebcomicPage): Promise<WebcomicPage> {
    const [page] = await db.insert(webcomicPages).values(pageData).returning();
    return page;
  }

  async updateWebcomicPage(id: number, updates: Partial<WebcomicPage>): Promise<WebcomicPage> {
    const [page] = await db
      .update(webcomicPages)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(webcomicPages.id, id))
      .returning();
    return page;
  }

  async deleteWebcomicPage(id: number): Promise<void> {
    await db.delete(webcomicPages).where(eq(webcomicPages.id, id));
  }

  // Advertisement operations
  async getAdvertisements(active?: boolean): Promise<Advertisement[]> {
    if (active !== undefined) {
      return await db
        .select()
        .from(advertisements)
        .where(eq(advertisements.isActive, active))
        .orderBy(desc(advertisements.createdAt));
    }

    return await db
      .select()
      .from(advertisements)
      .orderBy(desc(advertisements.createdAt));
  }

  async getAdvertisement(id: number): Promise<Advertisement | undefined> {
    const [ad] = await db.select().from(advertisements).where(eq(advertisements.id, id));
    return ad;
  }

  async createAdvertisement(adData: InsertAdvertisement): Promise<Advertisement> {
    const [ad] = await db.insert(advertisements).values(adData).returning();
    return ad;
  }

  async updateAdvertisement(id: number, updates: Partial<Advertisement>): Promise<Advertisement> {
    const [ad] = await db
      .update(advertisements)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(advertisements.id, id))
      .returning();
    return ad;
  }

  async deleteAdvertisement(id: number): Promise<void> {
    await db.delete(advertisements).where(eq(advertisements.id, id));
  }

  // Email subscription operations
  async createEmailSubscription(insertSubscription: InsertEmailSubscription): Promise<EmailSubscription> {
    const [subscription] = await db
      .insert(emailSubscriptions)
      .values(insertSubscription)
      .returning();
    return subscription;
  }

  async getEmailSubscriptionByEmail(email: string): Promise<EmailSubscription | undefined> {
    const [subscription] = await db
      .select()
      .from(emailSubscriptions)
      .where(eq(emailSubscriptions.email, email));
    return subscription;
  }

  async getAllEmailSubscriptions(): Promise<EmailSubscription[]> {
    return await db.select().from(emailSubscriptions).orderBy(desc(emailSubscriptions.subscribedAt));
  }

  // Webcomic subscription operations
  async createWebcomicSubscription(subscriptionData: InsertWebcomicSubscription): Promise<WebcomicSubscription> {
    const [subscription] = await db
      .insert(webcomicSubscriptions)
      .values(subscriptionData)
      .returning();
    return subscription;
  }

  async deleteWebcomicSubscription(userId: number, webcomicId: number): Promise<void> {
    await db
      .delete(webcomicSubscriptions)
      .where(
        and(
          eq(webcomicSubscriptions.userId, userId),
          eq(webcomicSubscriptions.webcomicId, webcomicId)
        )
      );
  }

  async getUserWebcomicSubscriptions(userId: number): Promise<WebcomicSubscription[]> {
    const subscriptions = await db
      .select()
      .from(webcomicSubscriptions)
      .where(eq(webcomicSubscriptions.userId, userId));
    return subscriptions;
  }

  async getWebcomicSubscribers(webcomicId: number): Promise<(WebcomicSubscription & { user: User })[]> {
    const subscribers = await db
      .select({
        id: webcomicSubscriptions.id,
        userId: webcomicSubscriptions.userId,
        webcomicId: webcomicSubscriptions.webcomicId,
        subscribedAt: webcomicSubscriptions.subscribedAt,
        user: {
          id: users.id,
          username: users.username,
          email: users.email,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(webcomicSubscriptions)
      .innerJoin(users, eq(webcomicSubscriptions.userId, users.id))
      .where(eq(webcomicSubscriptions.webcomicId, webcomicId));
    
    return subscribers as (WebcomicSubscription & { user: User })[];
  }
}

export const storage = new DatabaseStorage();
