# RaccoonSaints - Charity-focused Webcomic Platform

## Overview

RaccoonSaints is a comprehensive charity-focused webcomic platform that combines a public landing page with a full-featured webcomic reading and management system. The platform features role-based authentication, advertisement management, and creator tools - all built as a full-stack TypeScript application with React frontend and Express backend.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite with custom configuration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Validation**: Zod schemas shared between frontend and backend
- **Development**: tsx for TypeScript execution

### Project Structure
```
├── client/          # Frontend React application
├── server/          # Backend Express server
├── shared/          # Shared TypeScript types and schemas
├── migrations/      # Database migration files
└── dist/           # Production build output
```

## Key Components

### Frontend Components
- **Landing Page**: Public-facing hero section with email subscription and app access
- **Webcomic App**: Main authenticated application with comic browsing and advertisements
- **Comic Reader**: Full-featured reader with navigation and advertisement integration
- **Creator Dashboard**: Content management interface for comic creators
- **Admin Dashboard**: Platform administration with user, advertisement, and subscriber management
- **Authentication**: Replit OAuth integration with role-based access control
- **Advertisement System**: Clickable banner display system with position management

### Backend Services
- **Authentication System**: Replit OAuth with role-based permissions (standard/creator/admin)
- **Webcomic Management**: Full CRUD operations for comics and pages
- **Advertisement Management**: Admin-controlled clickable advertisement system
- **Email Subscription API**: Public email collection for launch notifications
- **User Management**: Admin-controlled creator account creation
- **Database Storage**: PostgreSQL with Drizzle ORM for data persistence

### Shared Schema
- **User Schema**: Role-based user model with OAuth integration (standard/creator/admin)
- **Webcomic Schema**: Comic series with creator relationships and publication status
- **Page Schema**: Individual comic pages with images and metadata
- **Advertisement Schema**: Clickable ads with position and status management
- **Email Subscription Schema**: Launch notification signups with consent tracking
- **Validation**: Comprehensive Zod schemas for type safety across all operations

## Data Flow

1. **User Interaction**: Visitor clicks "Notify Me" button on landing page
2. **Modal Display**: Email subscription form appears with validation
3. **Form Submission**: React Hook Form validates input using shared Zod schema
4. **API Request**: TanStack Query sends POST request to /api/subscribe
5. **Backend Processing**: Express validates data and stores subscription
6. **Response Handling**: Success/error feedback displayed via toast notifications

## External Dependencies

### Frontend Dependencies
- **UI Framework**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS with PostCSS processing
- **Icons**: Lucide React icon library
- **Date Handling**: date-fns for date manipulation
- **Carousel**: Embla Carousel for interactive components

### Backend Dependencies
- **Database**: Neon Database (PostgreSQL) via @neondatabase/serverless
- **ORM**: Drizzle ORM with Drizzle Kit for migrations
- **Session Management**: connect-pg-simple for PostgreSQL session store
- **Development Tools**: tsx for TypeScript execution

### Development Dependencies
- **Build**: esbuild for server bundling, Vite for client bundling
- **Replit Integration**: Custom plugins for development environment

## Deployment Strategy

### Development Mode
- Frontend: Vite dev server with HMR
- Backend: tsx with automatic restart
- Database: Configured for Neon Database with environment variables

### Production Build
1. Client build: `vite build` outputs to `dist/public`
2. Server build: `esbuild` bundles server to `dist/index.js`
3. Start: Node.js serves bundled application
4. Database: Drizzle migrations applied via `drizzle-kit push`

### Environment Configuration
- `DATABASE_URL`: PostgreSQL connection string (required)
- `NODE_ENV`: Environment mode (development/production)
- Path aliases configured for clean imports (@/, @shared/)

## Changelog

```
Changelog:
- July 02, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```